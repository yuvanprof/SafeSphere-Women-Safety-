SafeSphere — Women Safety Ecosystem Prototype
Team concept: Team hacktriz | My Bharat Hack for Social Cause | HSC|TN|03534

RUN
1. Extract the ZIP.
2. Open index.html in a modern browser. For browser geolocation, use localhost or HTTPS and grant permission.
3. Try the manual SOS preview, simulated signal assessment, location permission, and SMS draft preview.

IMPORTANT
This is an original demonstration prototype. The distress assessment is simulated rule-based logic, not a trained AI model. SOS events are not sent to a backend or emergency services. SMS only opens a draft where supported. GSM hardware, Firebase, production authentication, real AI, and trusted-contact delivery are not implemented. Do not use as a real emergency service.

NEXT DEVELOPMENT STEPS
- Build a React Native app and request device permissions only when needed.
- Train and validate distress models with consented, representative data; measure false positives and missed detections.
- Add authenticated backend and encrypted handling for location/contact data.
- Integrate real SMS only with explicit user consent and test devices/carrier conditions.
- Test fallback behavior, cancellation, battery impact, privacy, and accessibility.
